import { Component, Input, OnInit } from '@angular/core';
import { EcommerceService } from '../service/ecommerce.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input('productLength') productLength: any;
  cartDatas = [];
  cartLenght : any = 0;
  constructor( private ecommerceService : EcommerceService ) { }
  
  ngOnInit() {
    console.log('productLength', this.productLength);
    this.cartLenght = this.productLength;
    }

 ngOnChanges(){
  console.log('productLength', this.productLength);
  this.cartLenght = this.productLength;
 }

}
