import { Component, OnInit } from '@angular/core';
import { EcommerceService } from '../service/ecommerce.service';

@Component({
   selector: 'app-product-page',
   templateUrl: './product-page.component.html',
   styleUrls: ['./product-page.component.css']
})
export class ProductPageComponent implements OnInit {
   products: any = [];
   successAlert = false;
   loader = true;
   data: any;
   productLength: any;
   cartDatas = [];
   loaderFinal: any;


   filterValue: String;
   normal: any = [];
   back: any = [];
   productspreviousData: any;

   constructor(private ecommerceService: EcommerceService) { }

   ngOnInit() {
      this.GetProducts();
      this.cartData();
   }

   cartData() {
      this.cartDatas = this.ecommerceService.showToCard();
      this.productLength = this.cartDatas.length;
      console.log('rafeeq', this.cartDatas);
   }

   GetProducts() {
      this.ecommerceService.getData().subscribe(res => {
         this.products = res;
         this.productspreviousData = res;
         this.loader = false
      });
   }

   onAddToCart(val: object) {

      this.successAlert = true;
      this.productLength = this.ecommerceService.addToCart(val);

      
   }

   showProductCard() {
      this.ecommerceService.showToCard();
   }

   falseAlert() {
      this.successAlert = false;
   }

   onFilter(val: any) {
      this.products = this.productspreviousData;
      this.products = this.products.filter(function (el: any) {
         if(val == "All"){
            this.products = this.productspreviousData;
         }
         return el.p_category == val
         
      }
      );
      //console.log(this.products);
   }


}