import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { EcommerceService } from "../service/ecommerce.service";


@Component({
   selector: 'app-card-page',
   templateUrl: './cart-page.component.html',
   styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent implements OnInit {
   constructor(private ecommerceService: EcommerceService, private router: Router) { }
   cartDatas = [];
   subTotalAns: number = 0;
   alertMsg = false;
   productLength: any;

   ngOnInit() {
      this.showData();
      this.subTotal();
   }
   showData() {
      this.cartDatas = this.ecommerceService.showToCard();
      this.productLength = this.cartDatas.length;
   }

   removeCartData(val: any) {
      for (let i = 0; i < this.cartDatas.length; i++) {
         if (this.cartDatas[i].name == val) {
            this.cartDatas.splice(i, 1);
            localStorage.setItem('cardData', JSON.stringify(this.cartDatas));
         }
      }
      this.productLength = this.cartDatas.length;
   }

   subTotal() {
      for (let i = 0; i < this.cartDatas.length; i++) {
         if (this.cartDatas[i].qty > 1) {
            this.cartDatas[i].subTotal = this.cartDatas[i].qty * this.cartDatas[i].p_cost;
         }
         else {
            this.cartDatas[i].subTotal = 1 * this.cartDatas[i].p_cost;

         }
      }
   }

   onQty(value: number, id: number) {
      let totalAmout = 0;
      for (let i = 0; i < this.cartDatas.length; i++) {
         if (this.cartDatas[i].p_id == id) {
            this.cartDatas[i].qty = value;
            this.cartDatas[i].subTotal = value * this.cartDatas[i].p_cost;
         }
         localStorage.setItem('cardData', JSON.stringify(this.cartDatas));
         totalAmout += this.cartDatas[i].subTotal;

         this.cartDatas = JSON.parse(localStorage.getItem('cardData'));
      }
   }


   onClearCart() {
      if (this.cartDatas.length == 0) {
         this.alertMsg = true;
      }
      else {
         this.alertMsg = false;
         this.cartDatas = [];
         this.ecommerceService.productCart = [];
         this.subTotalAns = 0;
         localStorage.removeItem("cardData");
      }
      this.productLength = this.cartDatas.length;
   }

   onContinueToShopping() {
      this.router.navigate(['./products']);
   }

}

