import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-page-alert',
  templateUrl: './cart-page-alert.component.html',
  styleUrls: ['./cart-page-alert.component.css']
})
export class CartPageAlertComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
